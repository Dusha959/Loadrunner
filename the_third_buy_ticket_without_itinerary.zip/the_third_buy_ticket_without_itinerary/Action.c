Action()
{

	lr_start_transaction("the_third_buy_ticket_without_itinerary");
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("1_transaction_go_to_link");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

/*Correlation comment - Do not change!  Original value='128395.80218712zzAtDfQpAHfDQzczpVfttf' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=userSession",
		"TagName=input",
		"Extract=value",
		"Name=userSession",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);

	web_url("welcome.pl", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/WebTours/", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("1_transaction_go_to_link",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("2_transaction_sign_up");

	web_url("login.pl", 
		"URL=http://{URL}:{Port}/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/WebTours/home.html", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("2_transaction_sign_up",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("3_transaction_user_information");

	web_add_auto_header("Origin", 
		"http://{URL}:{Port}");

	web_submit_data("login.pl_2", 
		"Action=http://{URL}:{Port}/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=info", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=passwordConfirm", "Value={password}", ENDITEM, 
		"Name=firstName", "Value=Viktoria", ENDITEM, 
		"Name=lastName", "Value=Gureva", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=Moscow", ENDITEM, 
		"Name=register.x", "Value=70", ENDITEM, 
		"Name=register.y", "Value=10", ENDITEM, 
		LAST);

	lr_end_transaction("3_transaction_user_information",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("4_transaction_login");

	web_revert_auto_header("Origin");

	web_submit_data("login.pl_3",
		"Action=http://{URL}:{Port}/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=info",
		"RecContentType=text/html",
		"Referer=http://{URL}:{Port}/cgi-bin/nav.pl?in=home",
		"Snapshot=t4.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value={login}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		"Name=login.x", "Value=0", ENDITEM,
		"Name=login.y", "Value=0", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_end_transaction("4_transaction_login",LR_AUTO);

	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("5_transaction_go_to_flights");

	web_url("Search Flights Button", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("5_transaction_go_to_flights",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("6_transaction_flight_information");

	web_add_auto_header("Origin", 
		"http://{URL}:{Port}");

	web_submit_data("reservations.pl", 
		"Action=http://{URL}:{Port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Los Angeles", ENDITEM, 
		"Name=departDate", "Value={depDate}", ENDITEM, 
		"Name=arrive", "Value=Portland", ENDITEM, 
		"Name=returnDate", "Value={retDate}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=80", ENDITEM, 
		"Name=findFlights.y", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_end_transaction("6_transaction_flight_information",LR_AUTO);

	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("7_transaction_choose_flight");

	web_submit_data("reservations.pl_2", 
		"Action=http://{URL}:{Port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/reservations.pl", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=352;187;03/25/2020", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=reserveFlights.x", "Value=73", ENDITEM, 
		"Name=reserveFlights.y", "Value=9", ENDITEM, 
		LAST);

	lr_end_transaction("7_transaction_choose_flight",LR_AUTO);

	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("8_transaction_payment");

	web_submit_data("reservations.pl_3", 
		"Action=http://{URL}:{Port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/reservations.pl", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value=Viktoria", ENDITEM, 
		"Name=lastName", "Value=Gureva", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=Moscow", ENDITEM, 
		"Name=pass1", "Value=Viktoria Gureva", ENDITEM, 
		"Name=creditCard", "Value=445896545", ENDITEM, 
		"Name=expDate", "Value=01/22", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=outboundFlight", "Value=352;187;03/25/2020", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=buyFlights.x", "Value=37", ENDITEM, 
		"Name=buyFlights.y", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		LAST);

	lr_end_transaction("8_transaction_payment",LR_AUTO);
	
	lr_end_transaction("the_third_buy_ticket_without_itinerary", LR_AUTO);

	return 0;
}