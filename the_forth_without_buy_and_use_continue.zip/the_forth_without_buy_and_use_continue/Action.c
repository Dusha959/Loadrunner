Action()
{
	lr_start_transaction("the_forth_without_buy_and_use_continue");
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("1_transaction_go_to_link");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/WebTours/", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("1_transaction_go_to_link",LR_AUTO);
	
	lr_think_time(5);

	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("2_transaction_sign_up");

	web_url("login.pl", 
		"URL=http://{URL}:{Port}/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/WebTours/home.html", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("2_transaction_sign_up",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("3_transaction_user_information");

	web_add_auto_header("Origin", 
		"http://{URL}:{Port}");

	web_submit_data("login.pl_4", 
		"Action=http://{URL}:{Port}/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=info", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/login.pl", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=passwordConfirm", "Value={password}", ENDITEM, 
		"Name=firstName", "Value=Sergey", ENDITEM, 
		"Name=lastName", "Value=Os", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=Magadan", ENDITEM, 
		"Name=register.x", "Value=57", ENDITEM, 
		"Name=register.y", "Value=16", ENDITEM, 
		LAST);

	lr_end_transaction("3_transaction_user_information",LR_AUTO);
	
	lr_think_time(5);

	web_reg_find("Text=Error", "Fail=found",LAST);
	
	lr_start_transaction("4_transaction_continue");

	web_revert_auto_header("Origin");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_url("button_next.gif", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?page=menus", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/login.pl", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("4_transaction_continue",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("5_transaction_go_to_flights");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("Search Flights Button", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("5_transaction_go_to_flights",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("6_transaction_flight_information");

	web_add_header("Origin", 
		"http://{URL}:{Port}");

	web_submit_data("reservations.pl", 
		"Action=http://{URL}:{Port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value={depDate}", ENDITEM, 
		"Name=arrive", "Value=Paris", ENDITEM, 
		"Name=returnDate", "Value={retDate}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=on", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=69", ENDITEM, 
		"Name=findFlights.y", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_end_transaction("6_transaction_flight_information",LR_AUTO);
	
	lr_end_transaction("the_forth_without_buy_and_use_continue", LR_AUTO);

	return 0;
}