Action()
{
	lr_start_transaction("4_without_buy_and_without_sign_off");

	lr_start_transaction("1_transaction_go_to_link");
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/WebTours/", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("1_transaction_go_to_link",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("2_transaction_login");
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_submit_data("login.pl_3",
		"Action=http://{URL}:{Port}/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=info",
		"RecContentType=text/html",
		"Referer=http://{URL}:{Port}/cgi-bin/nav.pl?in=home",
		"Snapshot=t15.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value={login}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		"Name=login.x", "Value=72", ENDITEM,
		"Name=login.y", "Value=5", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_end_transaction("2_transaction_login",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("3_transaction_go_to_flights");
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("Search Flights Button", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("3_transaction_go_to_flights",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("4_transaction_flight_information");
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	web_add_header("Origin", 
		"http://{URL}:{Port}");

	web_submit_data("reservations.pl", 
		"Action=http://{URL}:{Port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value={depDate}", ENDITEM, 
		"Name=arrive", "Value=Paris", ENDITEM, 
		"Name=returnDate", "Value={retDate}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=on", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=69", ENDITEM, 
		"Name=findFlights.y", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_end_transaction("4_transaction_flight_information",LR_AUTO);
	
	lr_end_transaction("4_without_buy_and_without_sign_off", LR_AUTO);

	return 0;
}