Action()
{
	
	lr_start_transaction("the_fifth_without_buy_with_sign_off");

	web_reg_find("Text=Error", "Fail=found",LAST);
	
	lr_start_transaction("1_transaction_go_to_link");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

/*Correlation comment - Do not change!  Original value='128402.51073309zzAtHAtpVtfiDDDDDQzcipcctiHf' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=userSession",
		"TagName=input",
		"Extract=value",
		"Name=userSession",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);

	web_url("welcome.pl", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/WebTours/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("1_transaction_go_to_link",LR_AUTO);
	
	lr_think_time(5);

	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("2_transaction_sign_up");

	web_url("login.pl", 
		"URL=http://{URL}:{Port}/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/WebTours/home.html", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("2_transaction_sign_up",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("3_transaction_user_information");

	web_add_auto_header("Origin", 
		"http://{URL}:{Port}");

	web_submit_data("login.pl_2", 
		"Action=http://{URL}:{Port}/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=info", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=passwordConfirm", "Value={password}", ENDITEM, 
		"Name=firstName", "Value=timur", ENDITEM, 
		"Name=lastName", "Value=gover", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=moscow", ENDITEM, 
		"Name=register.x", "Value=72", ENDITEM, 
		"Name=register.y", "Value=7", ENDITEM, 
		LAST);

	lr_end_transaction("3_transaction_user_information",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("4_transaction_login");

	web_revert_auto_header("Origin");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_submit_data("login.pl_3",
		"Action=http://{URL}:{Port}/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=info",
		"RecContentType=text/html",
		"Referer=http://{URL}:{Port}/cgi-bin/nav.pl?in=home",
		"Snapshot=t15.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value={login}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		"Name=login.x", "Value=72", ENDITEM,
		"Name=login.y", "Value=5", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_end_transaction("4_transaction_login",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("5_transaction_go_to_flights");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("Search Flights Button", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("5_transaction_go_to_flights",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("6_transaction_flight_information");

	web_add_header("Origin", 
		"http://{URL}:{Port}");

	web_submit_data("reservations.pl", 
		"Action=http://{URL}:{Port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Los Angeles", ENDITEM, 
		"Name=departDate", "Value={depDate}", ENDITEM, 
		"Name=arrive", "Value=Sydney", ENDITEM, 
		"Name=returnDate", "Value={retDate}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=66", ENDITEM, 
		"Name=findFlights.y", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_end_transaction("6_transaction_flight_information",LR_AUTO);

	lr_think_time(5);
	
	web_reg_find("Text=Error", "Fail=found",LAST);

	lr_start_transaction("7_transaction_sign_off");

	web_url("SignOff Button", 
		"URL=http://{URL}:{Port}/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{URL}:{Port}/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("7_transaction_sign_off",LR_AUTO);
	
	lr_end_transaction("the_fifth_without_buy_with_sign_off", LR_AUTO);

	return 0;
}